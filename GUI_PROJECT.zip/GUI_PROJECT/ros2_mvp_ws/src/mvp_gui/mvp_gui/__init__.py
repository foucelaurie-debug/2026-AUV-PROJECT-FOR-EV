﻿"""MVP GUI package."""
